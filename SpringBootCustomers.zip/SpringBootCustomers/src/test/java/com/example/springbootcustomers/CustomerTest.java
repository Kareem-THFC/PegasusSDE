package com.example.springbootcustomers;

import com.example.springbootcustomers.CUSTOMERS.Customer;
import com.example.springbootcustomers.CUSTOMERS.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class CustomerTest {

    @Mock
    private CustomerRepository pdr;
    private Customer underTest1, underTest2;



    }
