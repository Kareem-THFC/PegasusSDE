package com.example.springbootcustomers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCustomersApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootCustomersApplication.class, args);
    }
}

