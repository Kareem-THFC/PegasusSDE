package hu.unideb.inf;

import java.sql.SQLException;
import java.util.List;

import hu.unideb.inf.model.*;
import org.h2.tools.Server;

public class Application {

    public static void main(String[] args) {
        try {
            // Start the H2 database server.
            startDatabase();

            // Try-with-resources: Create a new JpaVehicleDAO instance and manage resources automatically.
            try (VehicleDAO aDAO = new JpaVehicleDAO()) {
                // Perform data handling operations using the VehicleDAO.
                handleData(aDAO);

                // Retrieve vehicles from the database.
                List<Vehicle> vehicles = aDAO.getVehicles();
                // Display or process the retrieved vehicles as needed.
                displayVehicles(vehicles);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handle data operations using the VehicleDAO.
     * @param aDAO The VehicleDAO instance for data manipulation.
     */
    public static void handleData(VehicleDAO aDAO) {

        Vehicle a1 = new Vehicle();
        a1.setVehicle_type("Car");
        a1.setModel("Phantom");
        a1.setBrand("Rolls-Royce");
        a1.setDailyRate("22");

        Vehicle a2 = new Vehicle();
        a2.setVehicle_type("Car");
        a2.setModel("Aventador");
        a2.setBrand("Lamborghini");
        a2.setDailyRate("28");

        Vehicle a3 = new Vehicle();
        a3.setVehicle_type("Jet");
        a3.setModel("Gulfstream");
        a3.setBrand("G650");
        a3.setDailyRate("32");

        Vehicle a4 = new Vehicle();
        a4.setVehicle_type("Plane");
        a4.setModel("Airbus");
        a4.setBrand("A380");
        a4.setDailyRate("34");

        // Save vehicles to the database.
        aDAO.saveVehicle(a1);
        aDAO.saveVehicle(a2);
        aDAO.saveVehicle(a3);
        aDAO.saveVehicle(a4);
    }

    /**
     * Start the H2 database server.
     * @throws SQLException If there's an issue starting the server.
     */
    private static void startDatabase() throws SQLException {
        // Start the H2 database server with TCP and web access.
        new Server().runTool("-tcp", "-web", "-ifNotExists");
    }

    /**
     * Display the list of vehicles.
     * @param vehicles The list of vehicles to display.
     */
    public static void displayVehicles(List<Vehicle> vehicles) {
        System.out.println("List of Vehicles:");
        for (Vehicle vehicle : vehicles) {
            System.out.println("ID: " + vehicle.getVehicle_id());
            System.out.println("Type: " + vehicle.getVehicle_type());
            System.out.println("Model: " + vehicle.getModel());
            System.out.println("Brand: " + vehicle.getBrand());
            System.out.println("Daily Rate: " + vehicle.getDailyRate());
            System.out.println();
        }
    }
}
