package hu.unideb.inf.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;

public  class JpaVehicleDAO implements VehicleDAO {

    // Create an EntityManagerFactory and an EntityManager.
    private final EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("br.com.fredericci.pu");
    private final EntityManager entityManager = entityManagerFactory.createEntityManager();

    @Override
    public void saveAnimal(Vehicle a) {

    }

    @Override
    public void deleteAnimal(Vehicle a) {

    }

    @Override
    public void updateAnimal(Vehicle a) {

    }

    @Override
    public List<Vehicle> getAnimals() {
        return null;
    }

    @Override
    public void saveVehicle(Vehicle vehicle) {  // Updated method name and parameter name for consistency
        // Begin a transaction, persist the Vehicle entity, and commit the transaction.
        entityManager.getTransaction().begin();
        entityManager.persist(vehicle);
        entityManager.getTransaction().commit();
    }

   @Override
    public void deleteVehicle(Vehicle vehicle) {
        // Begin a transaction, remove the Vehicle entity, and commit the transaction.
        entityManager.getTransaction().begin();
        entityManager.remove(vehicle);
        entityManager.getTransaction().commit();
    }

    @Override
    public void updateVehicle(Vehicle vehicle) {
        // Update the Vehicle entity by saving it (transaction handling is within the saveVehicle method).
        saveVehicle(vehicle);
    }



   @Override
    public List<Vehicle> getVehicles() {  // Updated method name for consistency
        // Create a typed query to retrieve a list of Vehicle entities.
        TypedQuery<Vehicle> query = entityManager.createQuery("SELECT v FROM Vehicle v", Vehicle.class);  // Updated alias from "a" to "v" for clarity
        List<Vehicle> vehicles = query.getResultList();
        return vehicles;
    }

    @Override
    public void close() throws Exception {
        // Close the EntityManager and EntityManagerFactory when done.
        entityManager.close();
        entityManagerFactory.close();
    }
}
