package hu.unideb.inf.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Vehicle implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int vehicle_id;
    private String vehicle_type;
    private String Model;
    private String brand;
    private String DailyRate;

    // Constructors, getters, and setters can be added here.

    /**
     * This class represents a Vehicle entity, which can be stored in the database.
     */

    /**
     * Get the unique identifier for the vehicle.
     * @return The unique identifier for the vehicle.
     */
    public int getVehicle_id() {
        return vehicle_id;
    }

    /**
     * Set the unique identifier for the vehicle.
     * @param vehicle_id The unique identifier for the vehicle.
     */
    public void setVehicle_id(int vehicle_id) {
        this.vehicle_id = vehicle_id;
    }

    /**
     * Get the type of the vehicle (e.g., car, truck).
     * @return The type of the vehicle.
     */
    public String getVehicle_type() {
        return vehicle_type;
    }

    /**
     * Set the type of the vehicle.
     * @param vehicle_type The type of the vehicle.
     */
    public void setVehicle_type(String vehicle_type) {
        this.vehicle_type = vehicle_type;
    }

    /**
     * Get the model of the vehicle.
     * @return The model of the vehicle.
     */
    public String getModel() {
        return Model;
    }

    /**
     * Set the model of the vehicle.
     * @param model The model of the vehicle.
     */
    public void setModel(String model) {
        Model = model;
    }

    /**
     * Get the brand or manufacturer of the vehicle.
     * @return The brand or manufacturer of the vehicle.
     */
    public String getBrand() {
        return brand;
    }

    /**
     * Set the brand or manufacturer of the vehicle.
     * @param brand The brand or manufacturer of the vehicle.
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * Get the daily rental rate for the vehicle.
     * @return The daily rental rate for the vehicle.
     */
    public String getDailyRate() {
        return DailyRate;
    }

    /**
     * Set the daily rental rate for the vehicle.
     * @param dailyRate The daily rental rate for the vehicle.
     */
    public void setDailyRate(String dailyRate) {
        DailyRate = dailyRate;
    }
}
