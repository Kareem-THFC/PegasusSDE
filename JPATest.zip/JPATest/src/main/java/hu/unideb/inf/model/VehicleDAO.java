package hu.unideb.inf.model;

import java.util.List;

public interface VehicleDAO extends AutoCloseable {
    // CRUD methods for managing Vehicle entities

    /**
     * Creates (inserts) a new Vehicle entity in the database.
     * @param a The Vehicle entity to be saved.
     */
    public void saveAnimal(Vehicle a); // C

    /**
     * Deletes a Vehicle entity from the database.
     * @param a The Vehicle entity to be deleted.
     */
    public void deleteAnimal(Vehicle a); // D

    /**
     * Updates an existing Vehicle entity in the database.
     * @param a The Vehicle entity with updated data.
     */
    public void updateAnimal(Vehicle a); // U

    /**
     * Retrieves a list of all Vehicle entities from the database.
     * @return A list of Vehicle entities (Read operation).
     */
    public List<Vehicle> getAnimals(); // R

    void saveVehicle(Vehicle vehicle);

    void deleteVehicle(Vehicle vehicle);

    void updateVehicle(Vehicle vehicle);

    List<Vehicle> getVehicles();
}
