package hu.unideb.inf.model;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileVehicleDAO extends JpaVehicleDAO {

    private List<Vehicle> vehicles; // Changed variable name for consistency

    public FileVehicleDAO() {
        // Deserialization
        try (FileInputStream fis = new FileInputStream("vehicles.ser")) {
            try (ObjectInputStream ois = new ObjectInputStream(fis)) {
                vehicles = (List<Vehicle>) ois.readObject();
            }
        } catch (IOException | ClassNotFoundException e) {
            vehicles = new ArrayList<>();
        }
    }

    /**
     * Serializes the list of vehicles.
     */
    private void serialize() {
        try (FileOutputStream fos = new FileOutputStream("vehicles.ser");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) { // Removed the redundant semicolon
            oos.writeObject(vehicles);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void saveVehicle(Vehicle vehicle) { // Changed method and parameter names for consistency
        if (!vehicles.contains(vehicle)) vehicles.add(vehicle);
        serialize();
    }

    @Override
    public void deleteVehicle(Vehicle vehicle) { // Changed method and parameter names for consistency
        vehicles.remove(vehicle);
        serialize();
    }

    @Override
    public void updateVehicle(Vehicle vehicle) { // Changed method and parameter names for consistency
        vehicles.remove(vehicle); // Change the equals method of the Vehicle class for proper functioning.
        vehicles.add(vehicle);
        serialize();
    }

    @Override
    public List<Vehicle> getVehicles() { // Changed method name for consistency
        return vehicles;
    }

    @Override
    public void close() throws Exception {
        serialize();
    }
}
